const servicesData = [
    {
       s_no: "1",
       s_name:"Web design",
       s_desc:"Creating custom, responsive websites that blend innovative design with seamless functionality to meet your unique business needs",
    },

    {
        s_no: "2",
        s_name:"UI/UX Design & Optimization",
        s_desc:"Designing intuitive, user-centric interfaces and optimizing user experiences to ensure seamless interaction and engagement.",
     },

     {
        s_no: "3",
        s_name:"Responsive Web Design",
        s_desc:"Ensuring your website is fully responsive and optimized for all devices, offering smooth performance across desktops, tablets, and mobile screens.",
     },

     {
      s_no: "4",
      s_name:"Website Performance Optimization",
      s_desc:"Enhancing website speed and performance through efficient coding and optimization techniques.",
   },
     
]

export default servicesData